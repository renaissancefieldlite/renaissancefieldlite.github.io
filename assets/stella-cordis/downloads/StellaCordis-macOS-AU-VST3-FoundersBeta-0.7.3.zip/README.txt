StellaCordis Founders Beta 0.7.3 - Mac Patch 1
Renaissance Field Lite
Mirror Architecture Music Division

Included formats:
- VST3: StellaCordis.vst3
- AU: StellaCordis.component

Patch 1 note:
- Preset 01 / Mirror Core is tuned as the stronger first-load sound:
  - Mirror section ON
  - ARP ON at 1/16
  - Pattern: Down
  - Motion: full
  - Gate: 0.42
  - Swing: 0.00

macOS install:
1. Quit your DAW.
2. Copy StellaCordis.vst3 to:
   ~/Library/Audio/Plug-Ins/VST3/
3. Copy StellaCordis.component to:
   ~/Library/Audio/Plug-Ins/Components/
4. Reopen your DAW.
5. Rescan plug-ins if StellaCordis does not appear immediately.

Finding StellaCordis in your DAW:
Quick path: Plug-ins > VST3 > RenaissanceFieldLite > StellaCordis

1. Open your DAW plug-in browser.
2. Choose VST3 or Audio Units.
3. Open RenaissanceFieldLite. Some hosts may display it as Renaissance Field Lite.
4. Load StellaCordis on an instrument or MIDI track.

This is not Ableton-only. Use it in any compatible AU/VST3 DAW host.

If you use the AU version, look under Plug-ins > Audio Units > RenaissanceFieldLite > StellaCordis.

Suggested first preset:
- Mirror Core

First sound-design tip:
- Bloom, Shimmer, Motion, Air, and Character are the main tone sweet spots. Start there before digging into deeper oscillator or filter settings.

Support:
info@renaissancefieldlite.com
